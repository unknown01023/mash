import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// We keep the users table but don't use it for this application
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Define schemas for API interactions
export const generateRequestSchema = z.object({
  prompt: z.string().min(1, "Prompt cannot be empty"),
  apiKey: z.string().min(1, "API key is required"),
  inputImage: z.string().optional(), // Base64 encoded uploaded image
});

export const generateResponseSchema = z.object({
  text: z.string(),
  imageData: z.string().optional(),
});

export type GenerateRequest = z.infer<typeof generateRequestSchema>;
export type GenerateResponse = z.infer<typeof generateResponseSchema>;
