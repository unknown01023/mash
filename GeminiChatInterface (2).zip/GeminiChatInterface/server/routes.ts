import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { GoogleGenerativeAI } from "@google/generative-ai";

// Define request body validation schema
const generateRequestSchema = z.object({
  prompt: z.string().min(1, "Prompt cannot be empty"),
  apiKey: z.string().min(1, "API key is required"),
  inputImage: z.string().optional(), // Base64 encoded uploaded image
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Image generation endpoint
  app.post("/api/generate", async (req, res) => {
    try {
      // Validate request body
      const validationResult = generateRequestSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Invalid request", 
          errors: validationResult.error.errors 
        });
      }
      
      const { prompt, apiKey, inputImage } = validationResult.data;
      
      // Create Google Generative AI client
      const genAI = new GoogleGenerativeAI(apiKey);
      
      // Use the image generation model
      const model = genAI.getGenerativeModel({ 
        model: "gemini-2.0-flash-exp-image-generation", 
        // Casting as any to work around type errors with new API features
        generationConfig: { responseModalities: ['Text', 'Image'] } as any
      });
      
      // Generate content
      let response;
      if (inputImage) {
        // If an image was uploaded, include it in the request
        const imageData = {
          mimeType: "image/jpeg",
          data: inputImage
        };
        
        // Create a multipart content with image and text
        const parts = [
          { text: prompt },
          { inlineData: imageData }
        ];
        
        // Using 'as any' to work around type limitations
        response = await model.generateContent(parts as any);
      } else {
        // Text-only prompt
        response = await model.generateContent(prompt);
      }
      
      let textResponse = "";
      let imageData = undefined;
      
      // Process response parts
      if (response.response?.candidates?.[0]?.content?.parts) {
        for (const part of response.response.candidates[0].content.parts) {
          if (part.text) {
            textResponse += part.text;
          } else if (part.inlineData) {
            imageData = part.inlineData.data;
          }
        }
      }
      
      // Send response
      res.json({ 
        text: textResponse,
        imageData 
      });
      
    } catch (error) {
      console.error("Error generating content:", error);
      
      // Check for specific error types
      if (error instanceof Error) {
        // Return appropriate error status and message
        if (error.message.includes("API key")) {
          return res.status(401).json({ message: "Invalid API key" });
        }
        if (error.message.includes("not found") || error.message.includes("model")) {
          return res.status(404).json({ message: "Model not found or unavailable" });
        }
        return res.status(500).json({ message: error.message });
      }
      
      // Generic error
      res.status(500).json({ message: "An error occurred while generating content" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
