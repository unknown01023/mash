import ChatInterface from "@/components/ChatInterface";

const Home = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <ChatInterface />
    </div>
  );
};

export default Home;
