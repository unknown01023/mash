import { useState, useEffect, useRef } from "react";
import { useToast } from "@/hooks/use-toast";
import Header from "./Header";
import ChatMessages from "./ChatMessages";
import ChatInput from "./ChatInput";
import { Message } from "@/lib/types";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Upload } from "lucide-react";

const ChatInterface = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content: "Welcome to Vex AI",
    }
  ]);
  const [apiKey, setApiKey] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [inputValue, setInputValue] = useState<string>("");
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  // Check for saved API key on initial load
  useEffect(() => {
    const savedApiKey = localStorage.getItem("gemini_api_key");
    if (savedApiKey) {
      setApiKey(savedApiKey);
    }
  }, []);

  const handleSendMessage = async (message: string) => {
    if (!apiKey) {
      toast({
        variant: "destructive",
        title: "API Key Required",
        description: "Please enter your Gemini API key to send messages.",
      });
      return;
    }

    // Add user message to chat
    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: message,
    };
    setMessages((prev) => [...prev, userMessage]);
    
    // Clear input and set loading state
    setInputValue("");
    setIsLoading(true);

    try {
      // Send message to server for processing
      const response = await apiRequest("POST", "/api/generate", {
        prompt: message,
        apiKey,
      });
      
      const result = await response.json();
      
      // Add AI response to chat
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: result.text || "I've processed your request.",
        imageData: result.imageData,
        additionalInfo: result.imageData ? "Image generated based on your description. Feel free to ask for more!" : undefined
      };
      
      setMessages((prev) => [...prev, aiMessage]);
    } catch (error) {
      console.error("Error generating content:", error);
      toast({
        variant: "destructive",
        title: "Error generating content",
        description: error instanceof Error ? error.message : "Failed to generate content. Please try again.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleApiKeySave = (key: string) => {
    localStorage.setItem("gemini_api_key", key);
    setApiKey(key);
    // No toast notification for API key save
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Check if the file is an image
    if (!file.type.startsWith('image/')) {
      toast({
        variant: "destructive",
        title: "Invalid file type",
        description: "Please upload an image file (JPEG, PNG, etc.).",
      });
      return;
    }

    // Check file size (max 15MB)
    if (file.size > 15 * 1024 * 1024) {
      toast({
        variant: "destructive",
        title: "File too large",
        description: "Please upload an image smaller than 15MB.",
      });
      return;
    }

    // Read the file as a data URL
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      setUploadedImage(dataUrl);
    };
    reader.readAsDataURL(file);
  };

  const handleSendWithImage = async () => {
    if (!apiKey) {
      toast({
        variant: "destructive",
        title: "API Key Required",
        description: "Please enter your Gemini API key to send messages.",
      });
      return;
    }

    if (!uploadedImage) {
      toast({
        variant: "destructive",
        title: "No Image Selected",
        description: "Please upload an image first.",
      });
      return;
    }

    if (!inputValue.trim()) {
      toast({
        variant: "destructive",
        title: "Prompt Required",
        description: "Please enter a text prompt to process with this image.",
      });
      return;
    }

    setIsLoading(true);

    try {
      // First, add the user message with the image to the chat
      const userMessage: Message = {
        id: Date.now().toString(),
        role: "user",
        content: inputValue,
        inputImageData: uploadedImage,
      };
      
      setMessages((prev) => [...prev, userMessage]);
      
      // Extract base64 data from the data URL (remove the prefix)
      const base64Data = uploadedImage.split(',')[1];
      
      // Send message to server for processing
      const response = await apiRequest("POST", "/api/generate", {
        prompt: inputValue,
        apiKey,
        inputImage: base64Data,
      });
      
      const result = await response.json();
      
      // Add AI response to chat
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: result.text || "I've analyzed the image.",
        imageData: result.imageData,
      };
      
      setMessages((prev) => [...prev, aiMessage]);
      
      // Clear the uploaded image and input after sending
      setUploadedImage(null);
      setInputValue("");
      
      // Clear the file input
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    } catch (error) {
      console.error("Error processing image:", error);
      toast({
        variant: "destructive",
        title: "Error processing image",
        description: error instanceof Error ? error.message : "Failed to process image. Please try again.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const clearUploadedImage = () => {
    setUploadedImage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <div className="flex flex-col h-screen">
      <Header 
        apiKey={apiKey} 
        onApiKeySave={handleApiKeySave} 
      />
      <ChatMessages 
        messages={messages} 
        isLoading={isLoading} 
      />
      
      {/* Image upload area - preview only */}
      {uploadedImage && (
        <div className="mx-4 mb-2 p-3 border-0 rounded-lg bg-gray-800 dark:bg-gray-900 shadow-md flex items-center">
          <div className="flex-shrink-0 w-16 h-16 mr-3 rounded-lg overflow-hidden shadow-md">
            <img src={uploadedImage} alt="Uploaded" className="w-full h-full object-cover" />
          </div>
          <div className="flex-grow">
            <p className="text-sm text-gray-300">Ready to process with your prompt</p>
            <Button 
              size="sm" 
              variant="destructive" 
              onClick={clearUploadedImage}
              className="mt-1 rounded-full hover:opacity-90 transition-all duration-200"
            >
              Remove
            </Button>
          </div>
        </div>
      )}
      
      <div className="flex items-center border-t border-gray-700 px-4 py-3 bg-gray-800 dark:bg-gray-900 shadow-inner">
        {/* Hidden file input */}
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleImageUpload}
          accept="image/*"
          className="hidden"
        />
        
        {/* Visible upload button */}
        <Button
          variant="ghost"
          size="icon"
          onClick={() => fileInputRef.current?.click()}
          disabled={isLoading}
          className="mr-2 text-gray-300 hover:text-gray-100 transition-all duration-200 rounded-full p-2 hover:bg-gray-700"
          title="Upload an image"
        >
          <Upload className="h-5 w-5" />
        </Button>
        
        <ChatInput 
          inputValue={inputValue}
          setInputValue={setInputValue}
          onSendMessage={uploadedImage ? handleSendWithImage : handleSendMessage}
          disabled={Boolean(!apiKey || isLoading)}
        />
      </div>
    </div>
  );
};

export default ChatInterface;
