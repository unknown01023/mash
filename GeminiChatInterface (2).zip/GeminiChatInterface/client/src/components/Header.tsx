import { Sparkles } from "lucide-react";
import ApiKeyInput from "./ApiKeyInput";

interface HeaderProps {
  apiKey: string;
  onApiKeySave: (key: string) => void;
}

const Header = ({ apiKey, onApiKeySave }: HeaderProps) => {
  const hasApiKey = !!apiKey;

  return (
    <header className="bg-gradient-to-r from-gray-900 to-gray-800 border-b border-gray-700 shadow-lg z-10 text-white rounded-b-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="h-10 w-10 rounded-full bg-gradient-to-r from-primary to-purple-600 flex items-center justify-center text-white">
              <Sparkles className="h-6 w-6" />
            </div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-purple-500 text-transparent bg-clip-text">Vex AI</h1>
          </div>
          <div>
            {!hasApiKey && (
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-900/30 text-red-300 border border-red-500/30">
                <span className="mr-1.5 h-2 w-2 rounded-full bg-red-400" />
                API Key Required
              </span>
            )}
          </div>
        </div>
        <ApiKeyInput 
          onSave={onApiKeySave} 
          hasKey={hasApiKey}
        />
      </div>
    </header>
  );
};

export default Header;
