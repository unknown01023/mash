import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ExternalLink } from "lucide-react";

interface ApiKeyInputProps {
  onSave: (apiKey: string) => void;
  hasKey: boolean;
}

const ApiKeyInput = ({ onSave, hasKey }: ApiKeyInputProps) => {
  const [apiKeyInput, setApiKeyInput] = useState<string>("");
  const [isObscured, setIsObscured] = useState<boolean>(true);
  const [expanded, setExpanded] = useState<boolean>(!hasKey);

  const handleSaveKey = () => {
    const trimmedKey = apiKeyInput.trim();
    if (trimmedKey) {
      onSave(trimmedKey);
      setApiKeyInput("");
      setIsObscured(true);
      setExpanded(false);
    }
  };

  if (!expanded && hasKey) {
    return (
      <Button 
        className="rounded-full bg-gradient-to-r from-primary to-purple-600 hover:opacity-90 text-white transition-all duration-200"
        onClick={() => setExpanded(true)}
      >
        Update API Key
      </Button>
    );
  }

  return (
    <div className="mt-2 p-3 bg-gray-800 dark:bg-gray-900 rounded-lg shadow-md">
      <div className="flex flex-col sm:flex-row gap-2">
        <Input 
          type={isObscured ? "password" : "text"}
          value={hasKey && isObscured ? "••••••••••••••••••••••" : apiKeyInput}
          placeholder="Enter your Gemini API Key"
          className="flex-1 border-0 bg-gray-700 dark:bg-gray-800 text-white rounded-full shadow-sm px-4 py-2 text-sm placeholder-gray-400 focus:outline-none focus:ring-primary"
          onChange={(e) => {
            setApiKeyInput(e.target.value);
            if (isObscured) setIsObscured(false);
          }}
          onFocus={() => {
            if (hasKey && isObscured) {
              setApiKeyInput("");
              setIsObscured(false);
            }
          }}
        />
        <div className="flex gap-2">
          <Button 
            className="rounded-full bg-gradient-to-r from-primary to-purple-600 hover:opacity-90 text-white transition-all duration-200"
            onClick={handleSaveKey}
            disabled={!apiKeyInput.trim()}
          >
            Save Key
          </Button>
          <Button 
            className="rounded-full bg-gray-700 dark:bg-gray-800 hover:bg-gray-600 dark:hover:bg-gray-700 text-white transition-all duration-200"
            onClick={() => window.open('https://aistudio.google.com/app/apikey', '_blank')}
          >
            <ExternalLink className="h-4 w-4 mr-1" /> Get API Key
          </Button>
        </div>
      </div>
      <p className="mt-2 text-xs text-gray-400">Your API key is stored locally and never sent to our servers.</p>
    </div>
  );
};

export default ApiKeyInput;
