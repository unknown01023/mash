import { useEffect, useRef } from "react";
import { Message } from "@/lib/types";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Download, Sparkles } from "lucide-react";

interface ChatMessagesProps {
  messages: Message[];
  isLoading: boolean;
}

const ChatMessages = ({ messages, isLoading }: ChatMessagesProps) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);
  
  // Function to download an image
  const handleDownloadImage = (imageData: string, isBase64: boolean) => {
    let downloadUrl = imageData;
    
    // If it's a base64 string, create a data URL
    if (isBase64) {
      downloadUrl = `data:image/png;base64,${imageData}`;
    }
    
    // Create a temporary anchor element
    const a = document.createElement('a');
    a.href = downloadUrl;
    a.download = `gemini-image-${Date.now()}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-900">
      {messages.map((message) => (
        <div 
          key={message.id}
          className={`flex items-start max-w-3xl mx-auto ${message.role === "user" ? "justify-end" : ""}`}
        >
          {message.role === "assistant" && (
            <div className="flex-shrink-0 mr-3">
              <div className="h-10 w-10 rounded-full bg-gradient-to-r from-primary to-purple-600 flex items-center justify-center text-white font-bold shadow-md">
                <Sparkles className="h-5 w-5" />
              </div>
            </div>
          )}
          
          <div className={`${
            message.role === "user" 
              ? "bg-gradient-to-r from-primary to-purple-700 text-white" 
              : "bg-gray-800 text-gray-100"
            } rounded-2xl shadow-md p-4 max-w-xl border-0 ${
              message.role === "user" 
                ? "shadow-purple-900/20" 
                : "shadow-gray-950/30"
            }`}
          >
            {message.id === "welcome" ? (
              <h1 className="text-4xl font-bold text-center bg-gradient-to-r from-primary to-purple-500 text-transparent bg-clip-text">
                {message.content}
              </h1>
            ) : (
              <p className={message.role === "user" ? "text-white" : "text-gray-100"}>
                {message.content}
              </p>
            )}
            
            {/* Uploaded image (shown in user messages) */}
            {message.inputImageData && (
              <div className="mt-3">
                <div className="rounded-lg overflow-hidden shadow-md">
                  <img 
                    src={message.inputImageData}
                    alt="Uploaded image" 
                    className="w-full h-auto max-h-96 object-cover"
                  />
                </div>
              </div>
            )}
            
            {/* Generated image (shown in AI responses) */}
            {message.imageData && (
              <div className="mt-3">
                <div className="rounded-lg overflow-hidden shadow-md">
                  <img 
                    src={`data:image/png;base64,${message.imageData}`}
                    alt="Generated image" 
                    className="w-full h-auto max-h-96 object-cover"
                  />
                </div>
                <div className="mt-2 flex justify-end">
                  <Button
                    size="sm"
                    onClick={() => handleDownloadImage(message.imageData || "", true)}
                    className="text-xs flex items-center gap-1 bg-gray-700 hover:bg-gray-600 text-white rounded-full px-3 py-1 transition-all duration-200"
                  >
                    <Download className="h-3 w-3" />
                    Download
                  </Button>
                </div>
              </div>
            )}
            
            {message.additionalInfo && (
              <p className={`text-sm mt-2 ${
                message.role === "user" ? "text-gray-100" : "text-gray-600"
              }`}>
                {message.additionalInfo}
              </p>
            )}
          </div>
          
          {message.role === "user" && (
            <div className="flex-shrink-0 ml-3">
              <div className="h-10 w-10 rounded-full bg-gradient-to-r from-gray-800 to-gray-700 flex items-center justify-center text-gray-200 font-bold shadow-md">
                You
              </div>
            </div>
          )}
        </div>
      ))}
      
      {isLoading && (
        <div className="flex items-start max-w-3xl mx-auto">
          <div className="flex-shrink-0 mr-3">
            <div className="h-10 w-10 rounded-full bg-gradient-to-r from-primary to-purple-600 flex items-center justify-center text-white shadow-md">
              <Sparkles className="h-5 w-5" />
            </div>
          </div>
          <div className="bg-gray-800 rounded-2xl shadow-md p-4 max-w-xl border-0">
            <div className="flex items-center space-x-3">
              <div className="flex space-x-1">
                <div className="h-2 w-2 rounded-full bg-primary/60 animate-pulse" style={{ animationDelay: '0ms' }} />
                <div className="h-2 w-2 rounded-full bg-primary/60 animate-pulse" style={{ animationDelay: '300ms' }} />
                <div className="h-2 w-2 rounded-full bg-primary/60 animate-pulse" style={{ animationDelay: '600ms' }} />
              </div>
              <p className="text-gray-300">Generating response...</p>
            </div>
          </div>
        </div>
      )}
      
      <div ref={messagesEndRef} />
    </div>
  );
};

export default ChatMessages;
