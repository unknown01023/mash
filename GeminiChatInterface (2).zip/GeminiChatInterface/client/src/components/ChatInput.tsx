import { FormEvent } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send } from "lucide-react";

interface ChatInputProps {
  inputValue: string;
  setInputValue: (value: string) => void;
  onSendMessage: (message: string) => void;
  disabled: boolean;
}

const ChatInput = ({ 
  inputValue, 
  setInputValue, 
  onSendMessage, 
  disabled 
}: ChatInputProps) => {
  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    
    const trimmedMessage = inputValue.trim();
    if (trimmedMessage) {
      onSendMessage(trimmedMessage);
    }
  };

  return (
    <form 
      className="flex flex-1 items-center space-x-2" 
      onSubmit={handleSubmit}
    >
      <div className="relative flex-1">
        <Input
          type="text"
          placeholder="Type your message here..."
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          className="block w-full pl-4 pr-10 py-3 border-0 dark:bg-gray-800 dark:text-gray-100 rounded-full shadow-sm focus:ring-primary focus:border-primary"
          disabled={disabled}
        />
      </div>
      <Button 
        type="submit" 
        disabled={disabled || !inputValue.trim()} 
        className="inline-flex justify-center items-center p-2 border border-transparent rounded-full bg-gradient-to-r from-primary to-purple-600 text-white shadow-sm hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
      >
        <Send className="h-5 w-5" />
      </Button>
    </form>
  );
};

export default ChatInput;
