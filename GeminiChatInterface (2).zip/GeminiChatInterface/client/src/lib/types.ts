export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  imageData?: string; // Base64 encoded image
  inputImageData?: string; // Base64 encoded uploaded image
  additionalInfo?: string;
}

export interface GenerateRequest {
  prompt: string;
  apiKey: string;
  inputImage?: string; // Base64 encoded uploaded image
}

export interface GenerateResponse {
  text: string;
  imageData?: string; // Base64 encoded image
}
